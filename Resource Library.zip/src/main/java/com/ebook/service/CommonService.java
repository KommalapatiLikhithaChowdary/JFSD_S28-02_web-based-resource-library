package com.ebook.service;

public interface CommonService {

	public void removeSessionMessage();

}
